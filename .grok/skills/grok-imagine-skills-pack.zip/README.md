# Grok Imagine skills pack

Install (Grok Build / CLI):
```bash
unzip grok-imagine-skills-pack.zip -d ~/.grok/
```

For grok.com/skills Upload: use each `*-upload.zip` (SKILL.md at root).

Skills: characters-props-locations-refs · imagine-model-overrides · grok-chat-model-map · character-dna-extractor
Stack: grok-4.6 · grok-imagine-image-2.0 · video 1.0/1.5
