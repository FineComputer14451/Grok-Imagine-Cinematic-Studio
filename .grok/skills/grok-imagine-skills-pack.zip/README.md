# Grok Imagine skills pack

Bundled install for FineComputer14451 / Grok Imagine workflows.

## Contents

| Folder | Activate |
|--------|----------|
| `skills/characters-props-locations-refs/` | `ACTIVATE CHARACTERS_PROPS_LOCATIONS_REFS` |
| `skills/imagine-model-overrides/` | `ACTIVATE IMAGINE_MODEL_OVERRIDES hero` |
| `skills/grok-chat-model-map/` | `ACTIVATE GROK_CHAT_MODEL_MAP` |
| `skills/character-dna-extractor/` | `ACTIVATE CHARACTER_DNA_EXTRACTOR` |

## Install

```bash
unzip grok-imagine-skills-pack.zip -d ~/.grok/
# lands under ~/.grok/skills/<name>/
```

## Stack (Sep 2026)

- Chat/Code: `grok-4.6`
- Hero stills: `grok-imagine-image-2.0` (Quality Mode)
- Draft stills: `grok-imagine-image` (Fast Mode)
- Video: `grok-imagine-video` (1.0 edit/extend) · `grok-imagine-video-1.5` (final + audio)

Refs skill **auto-creates** Characters / Props / Locations plates by default.
