# Ref day checklist

**Project:** `<project>`  
**Model pin:** hero / balanced / draft  
**Mode:** auto-create (Quality / Image 2.0) unless explain-only  

## Mode first
- [ ] Auto-create enabled (default)
- [ ] `ACTIVATE IMAGINE_MODEL_OVERRIDES hero`
- [ ] Quality / Image 2.0 for locks
- [ ] Fast / 1.0 only for throwaway exploration

## Order
1. Locations → 2. Characters → 3. Props → 4. Board → 5. Sequence stills → 6. Video

## Locations
- [ ] Bible one-liner (time, weather, architecture, landmarks, grade)
- [ ] Establishing plate (Quality)
- [ ] 2–3 coverage angles
- [ ] Lock id: `loc_<name>_establish`

## Characters
- [ ] DNA note
- [ ] Plates: front · 3/4 · profile · full body (± expression / wardrobe)
- [ ] Hero lock(s): `char_<name>_hero_*`
- [ ] Later shots edit / i2v from hero

## Props
- [ ] One-liner (what / scale / material / era / marks)
- [ ] Hero + reverse (± detail)
- [ ] Lock: `prop_<name>_hero`

## Board
- [ ] `characters/` `props/` `locations/`
- [ ] Hero plate + variants + DNA line each
- [ ] Heroes on Image 2.0
- [ ] Optional `board/manifest.json` listing heroes / establish

## Post-board cross-ref
- [ ] `python scripts/cross_ref_check.py .` (or `ACTIVATE … check`)
- [ ] Zero failures (warnings ok unless `--strict`)
- [ ] DNA slugs match folders; every `reference_image_ids` plate exists
- [ ] Sample packets: clear `"sample": true` before lock

## Motion
- [ ] Audio motion → Video 1.5
- [ ] Edit / extend → Video 1.0 only
- [ ] No 1.0+1.5 mix without continuity pass

## Done when
New shots point at named hero plates — not re-describing identity from scratch.
